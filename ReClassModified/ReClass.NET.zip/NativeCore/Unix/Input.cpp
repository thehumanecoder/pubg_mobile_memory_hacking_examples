#include "NativeCore.hpp"
#include "../Shared/Keys.hpp"

RC_Pointer RC_CallConv InitializeInput()
{
	return nullptr;
}

bool RC_CallConv GetPressedKeys(RC_Pointer handle, Keys* state[], int* count)
{
	return false;
}

void RC_CallConv ReleaseInput(RC_Pointer handle)
{

}
