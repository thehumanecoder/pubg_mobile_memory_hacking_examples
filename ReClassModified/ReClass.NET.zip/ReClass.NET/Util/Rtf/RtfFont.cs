﻿namespace ReClassNET.Util.Rtf
{
	public enum RtfFont
	{
		Arial,
		Calibri,
		Consolas,
		CourierNew,
		Impact,
		LucidaConsole,
		Symbol,
		MSSansSerif
	}
}
