﻿namespace ReClassNET.MemoryScanner
{
	public enum ScanRoundMode
	{
		Strict,
		Normal,
		Truncate
	}
}
