﻿using System.Windows.Forms;

namespace ReClassNET.Forms
{
	public class IconForm : Form
	{
		public IconForm()
		{
			Icon = Properties.Resources.ReClassNet;
		}
	}
}
