﻿namespace ReClassNET.CodeGenerator
{
	public enum Language
	{
		Cpp,
		CSharp
	}
}
