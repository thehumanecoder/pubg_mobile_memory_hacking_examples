﻿namespace ReClassNET.Logger
{
	public enum LogLevel
	{
		Debug,
		Information,
		Warning,
		Error
	}
}
