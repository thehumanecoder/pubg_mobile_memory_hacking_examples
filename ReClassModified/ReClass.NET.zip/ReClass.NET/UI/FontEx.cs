﻿using System.Drawing;

namespace ReClassNET.UI
{
	public class FontEx
	{
		public Font Font { get; set; }
		public int Width { get; set; }
		public int Height { get; set; }
	}
}
